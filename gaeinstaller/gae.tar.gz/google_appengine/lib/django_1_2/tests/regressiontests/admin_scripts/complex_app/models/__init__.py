from admin_scripts.complex_app.models.bar import Bar
from admin_scripts.complex_app.models.foo import Foo

__all__ = ['Foo', 'Bar']
